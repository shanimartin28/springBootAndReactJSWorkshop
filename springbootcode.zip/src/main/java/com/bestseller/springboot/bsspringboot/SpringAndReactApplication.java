package com.bestseller.springboot.bsspringboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringAndReactApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringAndReactApplication.class, args);
    }
}

